import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Pc } from '../model/pc.model';
import { TypePc } from '../model/type.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-add-pc',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-pc.html',
  styleUrl: './add-pc.css'
})
export class AddPc implements OnInit {
  newPc = new Pc();
  types!: TypePc[];
  newIdType = 1;
  newType!: TypePc;

  constructor(
    private pcService: PcService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.types = this.pcService.listeTypes();
  }

  addPc(): void {
    this.newType = this.pcService.consulterType(this.newIdType);
    this.newPc.typePc = this.newType;

    this.newPc.dateCreation = new Date(
      this.newPc.dateCreation as unknown as string
    );

    this.pcService.ajouterPc(this.newPc);
    this.router.navigate(['/pcs']);
  }
}