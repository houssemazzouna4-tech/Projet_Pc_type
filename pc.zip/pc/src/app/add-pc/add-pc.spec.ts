import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddPc } from './add-pc';

describe('AddPc', () => {
  let component: AddPc;
  let fixture: ComponentFixture<AddPc>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AddPc]
    }).compileComponents();

    fixture = TestBed.createComponent(AddPc);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});