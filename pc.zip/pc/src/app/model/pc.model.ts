import { TypePc } from './type.model';

export class Pc {
  idPc!: number;
  nomPc!: string;
  prixPc!: number;
  dateCreation!: Date;
  typePc!: TypePc;
}