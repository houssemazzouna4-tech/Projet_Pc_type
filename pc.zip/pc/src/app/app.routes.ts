
import { Routes } from '@angular/router';
import { Pcs } from './pcs/pcs';
import { AddPc } from './add-pc/add-pc';
import { UpdatePc } from './update-pc/update-pc';

export const routes: Routes = [
  { path: 'pcs', component: Pcs },
  { path: 'add-pc', component: AddPc },
  { path: 'updatePc/:id', component: UpdatePc },
  { path: '', redirectTo: 'pcs', pathMatch: 'full' }
];
