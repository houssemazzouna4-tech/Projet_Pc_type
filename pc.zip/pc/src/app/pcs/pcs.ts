
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Pc } from '../model/pc.model';
import { PcService } from '../services/pc';

@Component({
  selector: 'app-pcs',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './pcs.html',
  styleUrl: './pcs.css'
})
export class Pcs {
  pcs: Pc[];

  constructor(private pcService: PcService) {
    this.pcs = this.pcService.listePcs();
  }

  supprimer(pc: Pc): void {
    if (confirm('Voulez-vous vraiment supprimer ce PC ?')) {
      this.pcService.supprimerPc(pc);
      this.pcs = this.pcService.listePcs();
    }
  }
}
